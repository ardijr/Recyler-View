# Recycler-View-Project

![Pertemuan 6 (1)](https://user-images.githubusercontent.com/101171623/195097400-a6a4d3bd-3e7b-4368-866f-0a6d9205eb72.png)

![Pertemuan 6 (2)](https://user-images.githubusercontent.com/101171623/195097425-4b3f396a-54d0-476f-9b8d-0a9e90360932.png)

![Pertemuan 6 (3)](https://user-images.githubusercontent.com/101171623/195097443-758ee367-373a-40a3-9cbe-9fa0edaeb04e.png)
